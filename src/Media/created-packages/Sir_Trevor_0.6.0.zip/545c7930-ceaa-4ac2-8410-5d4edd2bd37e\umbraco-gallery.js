﻿/*
  Umbraco Media Image Gallery Block by mindrevolution
*/

SirTrevor.Blocks.UmbracoGallery = (function () {

    // - umbraco ng references
    var ngi = angular.element("body").injector();
    var uImageHelper = ngi.get("imageHelper");
    var uDialogService = ngi.get("dialogService");
    var uMediaResource = ngi.get("mediaResource");

    var block;

    return SirTrevor.Block.extend({

        type: "umbraco_gallery",
        title: function() { return "Gallery"; },

        droppable: false,
        uploadable: false,
        pastable: false,
        ajaxable: false,

        icon_name: "poll",

        loadData: function (data) {
            block = this; // - unify context

            angular.forEach(data.items, function (item, index) {
                console.log("loadData item", item, index);
                block.setImage(item.id);
            });
        },

        onBlockRender: function () {
            // - block has no img src value, must be a new one, so open the media library ...
            if (typeof this.blockStorage.data.ids === "undefined") {
                // - preserve current scope for callback 'onMediaSelected'
                block = this;

                // - show media library and allow selection of multiple images
                uDialogService.mediaPicker({ onlyImages: true, callback: this.onMediaSelected, multiPicker: true });
            }
        },

        onMediaSelected: function (e) {
            console.log("onMediaSelected", e, e.length)
            var items = [];

            angular.forEach(e, function (mediaitem, index) {
                var item = {};

                item.id = mediaitem.id;
                item.contentTypeAlias = mediaitem.contentTypeAlias;

                items.push(item);
            });

            // - save gallery items
            block.setAndLoadData(items);
            block.ready();
        },

        setImage: function (mediaid) {
            // - preserve current scope for mediaResource callback
            var scope = block;

            //- fetch media (request intensive, but works for now)
            uMediaResource.getById(mediaid)
            .then(function (media) {
                var thumburl = uImageHelper.getThumbnailFromPath(uImageHelper.getImagePropertyValue({ imageModel: media }));

                scope.$editor.html($("<img>", { src: thumburl, class: "ust-previewimg" }));
            });
        }

    });

})();
